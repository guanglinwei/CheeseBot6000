Empty PV8 Game Template

Replace this README file
with a description of your
game and the license you
want to share your code
under.

Are you a Fantasy Club
Member? Join today for
free access to the demos,
docs, tutorials, artpacks,
and more.

You'll find everything you
need to start making your
own PV8 games!

Visit www.PixelVision8.com
to create your new account.

You can also join the
community on the official
discord server by visiting
www.discord.gg/pixelvision8 or
follow on twitter at
@pixelvision8
