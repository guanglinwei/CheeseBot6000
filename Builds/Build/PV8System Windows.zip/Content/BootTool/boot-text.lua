message = " " .. SystemName() ..
"\n" ..
"Copyright (C) "..os.date("%Y") ..
"\n\n\n" ..
"Pixel Vision 8 was created by Jesse Freeman and Christina-Antoinette Neofotistou in collaboration with Pedro Medeiros, Christer Kaitila and Shawn Rakowski." ..
"\n\n" ..
"With additional coding contributions by Matt Hughson and Dean Ellis." ..
"\n\n\n" ..
"The " .. SystemName() .. " is built on top of the open source Pixel Vision SDK." ..
"\n\n\n\n\n\n" ..
"Learn more at pixelvision8.com" ..
"\n\n"
